/****************************************************************************/
/* File        : MR_Test_Engine.h                                           */
/* Author      : Romano Mauri                                               */
/* Creation    : 22.03.2019                                                 */
/* Description : Classe di gestione della sincronizzazione dei dati.        */
/****************************************************************************/

#ifndef MR_TEST_ENGINE_H
#define MR_TEST_ENGINE_H

#include <QtCore>
//#include <QThread>
//#include <QWaitCondition>
//#include <QMutex>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QtNetwork>
#include <QDateTime>
#include <QRandomGenerator>

#include "MR_Test_Data.h"

/****************************************************************************/

#define TCP_PORT  24000

/****************************************************************************/

class MR_Test_Engine : public /*QThread*/ QObject
    {
    Q_OBJECT

    public:
        MR_Test_Engine();
        virtual ~MR_Test_Engine();

        bool    isRunning( void );
        void    StopEngine( void );

    public slots:
        void    ServerData( void );
        void    TimeOut( void );
        void    HttpDataReady( QNetworkReply *pResult );

    private:
        void    JsonDecoder( QString jBuffer );

        bool                  m_CicloThread;

        QNetworkAccessManager *m_HttpServer;
        //QNetworkRequest       *m_Service;

        QTimer                m_timer;
        QTcpSocket            *m_Client;

        MR_Test_Data          m_Data;

    };

/****************************************************************************/

#endif /* MR_TEST_ENGINE_H */

/****************************************************************************/
