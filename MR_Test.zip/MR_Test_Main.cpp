/****************************************************************************/
/* File        : MR_Test_Main                                               */
/* Author      : Romano Mauri                                               */
/* Creation    : 21.03.2019                                                 */
/* Description : Entry point dell'applicativo MR_Test                       */
/****************************************************************************/

#include <QApplication>
#include "MR_Test_Form.h"

/****************************************************************************/

int main( int argc , char *argv[] )
    {
    QApplication::setStyle( "Fusion" );
    QApplication app( argc , argv );

    MR_Test_Form form;

    return( app.exec());
    }

/****************************************************************************/
