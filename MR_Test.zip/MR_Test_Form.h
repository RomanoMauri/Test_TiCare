/****************************************************************************/
/* File        : MR_Test_Form.h                                             */
/* Author      : Romano Mauri                                               */
/* Creation    : 21.03.2019                                                 */
/* Description : Form di gestione dell'interfaccia.                         */
/****************************************************************************/

#ifndef MR_TEST_FORM_H
#define MR_TEST_FORM_H

//#include <QWidget>
#include <QtGui>
#include <QSettings>
#include <QMainWindow>
#include <QIntValidator>
#include <QTcpServer>
#include <QtWidgets>
#include <QtCharts/QtCharts>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>

#include "MR_Test_Data.h"
#include "MR_Test_Engine.h"

#define  SETTINGS_WINDOW_X                 "PosX"
#define  SETTINGS_WINDOW_Y                 "PosY"
#define  SETTINGS_WINDOW_W                 "DimX"
#define  SETTINGS_WINDOW_H                 "DimY"
#define  SETTINGS_SHOW_MAXIMIZED           "ShowMaximized"
#define  SETTINGS_TIME_QUERY               "TimeQuery"
#define  SETTINGS_URL_QUERY                "UrlQuery"
#define  SETTINGS_SIMULATE                 "Simulate"

#define  DEFAULT_WINDOW_W                  710
#define  DEFAULT_WINDOW_H                  480

/****************************************************************************/

class MR_Test_Form : public QMainWindow
    {
    Q_OBJECT

    public:
        explicit MR_Test_Form( QWidget *parent = 0 );
        virtual ~MR_Test_Form();

    public slots:
        void    ClientClose( void );
        void    ClientData( void );
        void    CmdSet( void );

    private:
        QWidget     m_Wnd;
        QSettings   *m_Settings;
        QTcpServer  *m_Server;
        QTcpSocket  *m_Client;

        int         m_WindowPosX;
        int         m_WindowPosY;
        int         m_WindowDimW;
        int         m_WindowDimH;
        bool        m_ShowMaximize;

        MR_Test_Data    m_Data;
        MR_Test_Engine  *m_Engine;
        QThread         *m_ThreadEng;

        QLabel      *lbl_Url;
        QLabel      *lbl_TOut;
        QLineEdit   *edt_Url;
        QLineEdit   *edt_TOut;
        QPushButton *btn_Set;
        QChart      *show_Chart;
        QChartView  *chartView;
        QCheckBox   *chk_Simulator;

        QLineSeries *m_GraphData;
        long        m_BaseTimeStamp;

        void CreateControls( void );
        void ReadSettings( void );
        void WriteSettings( void );
        void closeEvent( QCloseEvent *evt );
        

    };

/****************************************************************************/

#endif /* MR_TEST_FORM_H */

/****************************************************************************/
