/****************************************************************************/
/* File        : MR_Test_Data.h                                             */
/* Author      : Romano Mauri                                               */
/* Creation    : 23.03.2019                                                 */
/* Description : Classe di gestione dei dati scambiati tra le sezioni       */
/*               dell'applicativo.                                          */
/****************************************************************************/

#ifndef MR_TEST_DATA_H
#define	MR_TEST_DATA_H

#include <QString>

/****************************************************************************/

#define TAG_URL_START    "<Url>"
#define TAG_URL_END      "</Url>"
#define TAG_TOUT_START   "<TOut>"
#define TAG_TOUT_END     "</Tout>"
#define TAG_VALUE_START  "<Value>"
#define TAG_VALUE_END    "</Value>"
#define TAG_TSTAMP_START "<TStamp>"
#define TAG_TSTAMP_END   "</TStamp>"

/****************************************************************************/

class MR_Test_Data
    {
    public:
        MR_Test_Data();
        virtual ~MR_Test_Data();

        bool    Decode( QString parBuffer );
        QString EncodeParameters( void );
        QString EncodeValue( void );
        QString GetAddress( void );
        int     GetTimeQuery( void );
        long    GetTimeStamp( void );
        double  GetValue( void );
        void    SetAddress( QString parValue );
        void    SetTimeQuery( int parValue );
        void    SetTimeStamp( long parValue );
        void    SetValue( double parValue );

    private:
        int         m_msTimeQuery;
        QString     m_UrlAddress;
        double      m_Value;
        long        m_TimeStamp;

    };

/****************************************************************************/

#endif	/* MR_TEST_DATA_H */

/****************************************************************************/
