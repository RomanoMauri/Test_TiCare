/****************************************************************************/
/* File        : MR_Test_Form.h                                             */
/* Author      : Romano Mauri                                               */
/* Creation    : 21.03.2019                                                 */
/* Description : Form di gestione dell'interfaccia.                         */
/****************************************************************************/

#include "MR_Test_Form.h"

/*! *************************************************************************
* @par          MR_Test_Form
* @author       Romano Mauri
* @brief        Costruttore del form.
* @date         21.03.2019
****************************************************************************/

MR_Test_Form::MR_Test_Form( QWidget *parent ) :
              QMainWindow( parent )
    {
    ReadSettings();

    m_Wnd.setWindowFlags( m_Wnd.windowFlags() & ~( Qt::WindowContextHelpButtonHint | Qt::WindowMaximizeButtonHint | Qt::WindowMinimizeButtonHint ));
    m_Wnd.setWindowTitle( "TEST - Romano Mauri" );
    m_Wnd.setMinimumSize( DEFAULT_WINDOW_W , DEFAULT_WINDOW_H );
    m_Wnd.setMaximumSize( DEFAULT_WINDOW_W , DEFAULT_WINDOW_H );

    m_BaseTimeStamp = 0;
    m_GraphData = new QLineSeries();
    m_GraphData->clear();

    CreateControls();
    edt_Url->setText( m_Data.GetAddress());
    edt_TOut->setText( QString::number( m_Data.GetTimeQuery()));
    chk_Simulator->setChecked( m_Data.IsSimulator());

    if( m_ShowMaximize )
        m_Wnd.showMaximized();
    else
        {
        m_Wnd.move( m_WindowPosX , m_WindowPosY );
        m_Wnd.resize( m_WindowDimW , m_WindowDimH );
        }
    m_Wnd.show();

    m_Server = new QTcpServer( this );
    connect( m_Server , SIGNAL( newConnection()) , this , SLOT( CmdSet()));
    m_Server->listen( QHostAddress::Any , TCP_PORT );
    m_Client = NULL;

    m_Engine = new MR_Test_Engine();
    }

/*! *************************************************************************
* @par          ~MR_Test_Form
* @author       Romano Mauri
* @brief        Distruttore del form.
* @date         21.03.2019
****************************************************************************/

MR_Test_Form::~MR_Test_Form()
    {
    if( m_Server )
        {
        disconnect( m_Server , SIGNAL( newConnection()) , this , SLOT( CmdSet()));
        m_Server->close();
        //delete m_Server;
        m_Server = NULL;
        }

    if( m_Engine )
        delete m_Engine;

    if( m_GraphData )
        {
        m_GraphData->clear();	
        delete m_GraphData;
        }

    WriteSettings();
    delete m_Settings;
    }

/*! *************************************************************************
* @par          CreateControls
* @author       Romano Mauri
* @brief        Funzione per creare tutti i controlli e posizionarli sulla
*               finestra.
* @date         21.03.2019
****************************************************************************/

void MR_Test_Form::CreateControls()
    {
    lbl_Url = new QLabel( "URL:" );
    lbl_Url->setGeometry(QRect( 10 , 10 , 60 , 26 ));
    lbl_Url->setFrameShape(QFrame::Panel);
    lbl_Url->setFrameShadow(QFrame::Sunken);
    lbl_Url->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
    lbl_Url->setParent( &m_Wnd );

    edt_Url = new QLineEdit();
    edt_Url->setGeometry(QRect( 75 , 10 , 310 , 26 ));
    edt_Url->setFocusPolicy( Qt::StrongFocus );
    edt_Url->setAlignment(Qt::AlignLeft|Qt::AlignVCenter);
    edt_Url->setParent( &m_Wnd );

    lbl_TOut = new QLabel( "TOut (ms):" );
    lbl_TOut->setGeometry(QRect( 395 , 10 , 60 , 26 ));
    lbl_TOut->setFrameShape(QFrame::Panel);
    lbl_TOut->setFrameShadow(QFrame::Sunken);
    lbl_TOut->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
    lbl_TOut->setParent( &m_Wnd );

    edt_TOut = new QLineEdit();
    edt_TOut->setGeometry(QRect( 460 , 10 , 60 , 26 ));
    edt_TOut->setFocusPolicy( Qt::StrongFocus );
    edt_TOut->setAlignment(Qt::AlignRight|Qt::AlignVCenter);
    edt_TOut->setValidator( new QIntValidator( 0 , 60000 ));
    edt_TOut->setParent( &m_Wnd );

    chk_Simulator = new QCheckBox("Simulate" );
    chk_Simulator->setGeometry(QRect( 530 , 10 , 60 , 26 ));
    chk_Simulator->setParent( &m_Wnd );
    
    btn_Set = new QPushButton( "Set" );
    btn_Set->setGeometry(QRect( 600 , 10, 100, 26 ));
    btn_Set->setFocusPolicy(Qt::NoFocus);
    btn_Set->setParent( &m_Wnd );
    connect( btn_Set , SIGNAL( clicked()) , this , SLOT( CmdSet()));

    show_Chart = new QChart();
    show_Chart->setGeometry(QRect( 10 , 50 , 690 , 420 ));
    show_Chart->setParent( &m_Wnd );
    show_Chart->legend()->hide();
    show_Chart->addSeries( m_GraphData );	

    chartView = new QChartView( show_Chart );
    chartView->setRenderHint( QPainter::Antialiasing );
    chartView->setGeometry(QRect( 10 , 50 , 690 , 420 ));
    chartView->setParent( &m_Wnd );
    }

/*! *************************************************************************
* @par          closeEvent
* @author       Romano Mauri
* @brief        Funzione per chiudere l'applicazione in risposta alla
*               pressione del tasto "X".
* @date         21.03.2019
****************************************************************************/

void MR_Test_Form::closeEvent( QCloseEvent *evt )
    {
    if( !m_Wnd.isMaximized())
        {
        QSize szWnd = m_Wnd.size();
        QPoint pntWnd = m_Wnd.pos();

        m_WindowDimW = szWnd.width();
        m_WindowDimH = szWnd.height();
        m_WindowPosX = pntWnd.x();
        m_WindowPosY = pntWnd.y();
        m_ShowMaximize = false;
        }
    else
        m_ShowMaximize = true;

    QMainWindow::closeEvent( evt );
    }

/*! *************************************************************************
* @par          ReadSettings
* @author       Romano Mauri
* @brief        Funzione per leggere le impostazioni del programma.
* @date         21.03.2019
****************************************************************************/

void MR_Test_Form::ReadSettings()
    {
    m_WindowPosX = m_WindowPosY = 100;
    m_WindowDimW = DEFAULT_WINDOW_W;
    m_WindowDimH = DEFAULT_WINDOW_H;
    m_ShowMaximize = false;

    m_Data.SetTimeQuery( 5000 );
    m_Data.SetAddress( QString( "https://www.bitstamp.net/api/v2/ticker/etheur" ));

    m_Settings = new QSettings( QSettings::IniFormat , QSettings::UserScope , "MR" , "MR_Test" );
    if( m_Settings )
        {
        if( m_Settings->contains( SETTINGS_WINDOW_X ))
            m_WindowPosX = m_Settings->value( SETTINGS_WINDOW_X ).toInt();
        if( m_Settings->contains( SETTINGS_WINDOW_Y ))
            m_WindowPosY = m_Settings->value( SETTINGS_WINDOW_Y ).toInt();
        if( m_Settings->contains( SETTINGS_WINDOW_W ))
            m_WindowDimW = m_Settings->value( SETTINGS_WINDOW_W ).toInt();
        if( m_Settings->contains( SETTINGS_WINDOW_H ))
            m_WindowDimH = m_Settings->value( SETTINGS_WINDOW_H ).toInt();
        if( m_Settings->contains( SETTINGS_SHOW_MAXIMIZED ))
            m_ShowMaximize = m_Settings->value( SETTINGS_SHOW_MAXIMIZED ).toBool();

        if( m_Settings->contains( SETTINGS_TIME_QUERY ))
            m_Data.SetTimeQuery( m_Settings->value( SETTINGS_TIME_QUERY ).toInt());
        if( m_Settings->contains( SETTINGS_URL_QUERY ))
            m_Data.SetAddress( m_Settings->value( SETTINGS_URL_QUERY ).toString());
        if( m_Settings->contains( SETTINGS_SIMULATE ))
            m_Data.SetSimulator(( m_Settings->value( SETTINGS_SIMULATE ).toInt() != 0 ) ? true : false );
        }
    }

/*! *************************************************************************
* @par          WriteSettings
* @author       Romano Mauri
* @brief        Funzione per memorizzare le impostazioni del programma.
* @date         21.03.2019
****************************************************************************/

void MR_Test_Form::WriteSettings()
    {
    if( m_Settings )
        {
        m_Settings->setValue( SETTINGS_WINDOW_X , m_WindowPosX );
        m_Settings->setValue( SETTINGS_WINDOW_Y , m_WindowPosY );
        m_Settings->setValue( SETTINGS_WINDOW_W , m_WindowDimW );
        m_Settings->setValue( SETTINGS_WINDOW_H , m_WindowDimH );
        m_Settings->setValue( SETTINGS_SHOW_MAXIMIZED , m_ShowMaximize );

        m_Settings->setValue( SETTINGS_TIME_QUERY , m_Data.GetTimeQuery());
        m_Settings->setValue( SETTINGS_URL_QUERY , m_Data.GetAddress());
        m_Settings->setValue( SETTINGS_SIMULATE , ( m_Data.IsSimulator()) ? 1 : 0 );

        m_Settings->sync();
        }
    }

/*! *************************************************************************
* @par          CmdSet
* @author       Romano Mauri
* @brief        Funzione per intercettare la pressione del bottone di
*               impostazione in modo da comunicare i nuovi parametri al
*               thread di recupero dati.
*               Viene utilizzata anche per intercettare l'evento di connessione
*               del motore di recupero dati in modo da mandare la parametrizzazione
*               al momento della connessione.
* @date         21.03.2019
****************************************************************************/

void MR_Test_Form::CmdSet()
    {
    m_Data.SetAddress( edt_Url->text());
    m_Data.SetTimeQuery( edt_TOut->text().toInt());
    m_Data.SetSimulator( chk_Simulator->isChecked());

    if( m_Server )
        {
        QString strParam = m_Data.EncodeParameters();

        if( !m_Client )
            {
            m_Client = m_Server->nextPendingConnection();
            if( m_Client )
                {
                connect( m_Client , SIGNAL( disconnected()) , this , SLOT( ClientClose()));
                connect( m_Client , SIGNAL( readyRead()) , this , SLOT( ClientData()));
                }
            }

        if( m_Client )
            m_Client->write( strParam.toLocal8Bit());
		
        m_BaseTimeStamp = 0;
	m_GraphData->clear();	
	//show_Chart->removeAllSeries();	
        show_Chart->createDefaultAxes();
        }
    }

/*! *************************************************************************
* @par          ClientClose
* @author       Romano Mauri
* @brief        Funzione per disconnettere il socket di recupero dati.
* @date         23.03.2019
****************************************************************************/

void MR_Test_Form::ClientClose()
    {
    if( m_Client )
        {
        disconnect( this , SLOT( ClientClose()));
        disconnect( this , SLOT( ClientData()));
        m_Client->disconnectFromHost();
        m_Client->close();

        //delete m_Client;
        m_Client = NULL;
        }
    }

/*! *************************************************************************
* @par          ClientData
* @author       Romano Mauri
* @brief        Funzione richiamata alla ricezione di nuovi dati.
*                Deve decodificare il buffer ricevuto ed inviare il dato
*                al grafico di visualizzazione.
* @date         23.03.2019
****************************************************************************/

void MR_Test_Form::ClientData()
    {
    int i;
    double minValue , maxValue;
    bool ret;
    QByteArray buffer;

    buffer.clear();
    if( m_Client )
        {
        while( m_Client->bytesAvailable() > 0 )
            buffer.append( m_Client->readAll());

        if( buffer.length() > 0 )
            {
            //std::string strDebug = QString::fromLocal8Bit( buffer.data()).toStdString();
            ret = m_Data.Decode( QString::fromLocal8Bit( buffer.data()));
            if( ret )
                {
                if( m_BaseTimeStamp == 0 )
                    m_BaseTimeStamp = m_Data.GetTimeStamp();

                minValue = maxValue = m_Data.GetValue();
                for( i = 0 ; i < m_GraphData->count() ; i++ )
                    {
                    QPointF p = m_GraphData->at( i );
                    if( p.x() == m_Data.GetTimeStamp() - m_BaseTimeStamp )
                        break;
                    
                    if( p.y() < minValue )
                        minValue = p.y();
                    if( p.y() > maxValue )
                        maxValue = p.y();
                    }
                if( i >= m_GraphData->count())
                    {
                    m_GraphData->append( m_Data.GetTimeStamp() - m_BaseTimeStamp , m_Data.GetValue());
                    
                    show_Chart->createDefaultAxes();
                    show_Chart->axisX()->setRange( QVariant::fromValue( 0 ) , QVariant::fromValue( m_Data.GetTimeStamp() - m_BaseTimeStamp ));
                    show_Chart->axisY()->setRange( QVariant::fromValue( minValue * 0.9 ) , QVariant::fromValue( maxValue * 1.1 ));
                    chartView->repaint();
                    }
                }
            }
        }
    }

/****************************************************************************/
