/****************************************************************************/
/* File        : MR_Test_Data.cpp                                           */
/* Author      : Romano Mauri                                               */
/* Creation    : 23.03.2019                                                 */
/* Description : Classe di gestione dei dati scambiati tra le sezioni       */
/*               dell'applicativo.                                          */
/****************************************************************************/

#include "MR_Test_Data.h"

/*! *************************************************************************
* @par          MR_Test_Data
* @author       Romano Mauri
* @brief        Costruttore della classe.
* @date         23.03.2019
****************************************************************************/

MR_Test_Data::MR_Test_Data()
    {
    m_msTimeQuery = 100;
    m_UrlAddress.clear();
    m_Value = 0;
    m_TimeStamp = 0;
    m_Simulator = false;
    }

/*! *************************************************************************
* @par          ~MR_Test_Message
* @author       Romano Mauri
* @brief        Distruttore della classe.
* @date         23.03.2019
****************************************************************************/

MR_Test_Data::~MR_Test_Data()
    {
    }

/*! *************************************************************************
* @par          GetTimeQuery
* @author       Romano Mauri
* @brief        Funzione per leggere il tempo di attesa tra due interrogazioni
*                al servizio.
* @date         23.03.2019
* @return       tempo di attesa tra due interrogazioni al servizio.
****************************************************************************/

int MR_Test_Data::GetTimeQuery()
    {
    return( m_msTimeQuery );
    }

/*! *************************************************************************
* @par          SetTimeQuery
* @author       Romano Mauri
* @brief        Funzione per impostare il tempo di attesa tra due interrogazioni
*                al servizio.
* @date         23.03.2019
* @param[in]    parValue = tempo di attesa tra due interrogazioni al servizio.
****************************************************************************/

void MR_Test_Data::SetTimeQuery( int parValue )
    {
    m_msTimeQuery = parValue;
    }

/*! *************************************************************************
* @par          GetTimeStamp
* @author       Romano Mauri
* @brief        Funzione per leggere l'orario della quotazione.
* @date         23.03.2019
* @return       Orario della quotazione.
****************************************************************************/

long MR_Test_Data::GetTimeStamp()
    {
    return( m_TimeStamp );
    }

/*! *************************************************************************
* @par          SetTimeStamp
* @author       Romano Mauri
* @brief        Funzione per impostare il tempo della quotazione.
* @date         23.03.2019
* @param[in]    parValue = orario della quotazione.
****************************************************************************/

void MR_Test_Data::SetTimeStamp( long parValue )
    {
    m_TimeStamp = parValue;
    }

/*! *************************************************************************
* @par          GetAddress
* @author       Romano Mauri
* @brief        Funzione per leggere l'indirizzo del servizio di fornitura dati.
* @date         23.03.2019
* @return       indirizzo del servizio di fornitura dati.
****************************************************************************/

QString MR_Test_Data::GetAddress()
    {
    return( m_UrlAddress );
    }

/*! *************************************************************************
* @par          SetAddress
* @author       Romano Mauri
* @brief        Funzione per impostare l'indirizzo del servizio di fornitura dati.
* @date         23.03.2019
* @param[in]    parValue = indirizzo del servizio di fornitura dati.
****************************************************************************/

void MR_Test_Data::SetAddress( QString parValue )
    {
    m_UrlAddress = parValue;
    }

/*! *************************************************************************
* @par          GetValue
* @author       Romano Mauri
* @brief        Funzione per leggere il valore di cambio.
* @date         23.03.2019
* @return       valore di cambio.
****************************************************************************/

double MR_Test_Data::GetValue()
    {
    return( m_Value );
    }

/*! *************************************************************************
* @par          SetValue
* @author       Romano Mauri
* @brief        Funzione per impostare il valore di cambio.
* @date         23.03.2019
* @param[in]    parValue = valore di cambio.
****************************************************************************/

void MR_Test_Data::SetValue( double parValue )
    {
    m_Value = parValue;
    }

/*! *************************************************************************
* @par          IsSimulator
* @author       Romano Mauri
* @brief        Funzione per leggere se è attiva la funzione di simulazione.
* @date         23.03.2019
* @return       TRUE se è attiva la simulazione.
****************************************************************************/

bool MR_Test_Data::IsSimulator()
    {
    return( m_Simulator );
    }

/*! *************************************************************************
* @par          SetSimulator
* @author       Romano Mauri
* @brief        Funzione per attivare la funzione di simulazione.
* @date         23.03.2019
* @param[in]    parValue = stato della simulazione.
****************************************************************************/

void MR_Test_Data::SetSimulator( bool parValue )
    {
    m_Simulator = parValue;
    }

/*! *************************************************************************
* @par          EncodeParameters
* @author       Romano Mauri
* @brief        Funzione per codificare in XML i parametri da inviare
*                sul socket.
* @date         23.03.2019
* @return       Stringa con i parametri da inviare.
****************************************************************************/

QString MR_Test_Data::EncodeParameters()
    {
    QString strParam;

    strParam = QString( "%1%2%3\n%4%5%6\n%7%8%9\n" ).arg( TAG_URL_START ).arg( m_UrlAddress ).arg( TAG_URL_END ).arg( TAG_TOUT_START ).arg( m_msTimeQuery ).arg( TAG_TOUT_END ).arg( TAG_SIMULATOR_START ).arg(( m_Simulator ) ? 1 : 0 ).arg( TAG_SIMULATOR_END );
    return( strParam );
    }

/*! *************************************************************************
* @par          EncodeValue
* @author       Romano Mauri
* @brief        Funzione per codificare in XML il valore della quotazione.
* @date         23.03.2019
* @return       Stringa con ilvalore della quotazione.
****************************************************************************/

QString MR_Test_Data::EncodeValue()
    {
    QString strParam;

    strParam = QString( "%1%2%3\n%4%5%6\n" ).arg( TAG_VALUE_START ).arg( m_Value ).arg( TAG_VALUE_END ).arg( TAG_TSTAMP_START ).arg( m_TimeStamp ).arg( TAG_TSTAMP_END );
    return( strParam );
    }

/*! *************************************************************************
* @par          Decode
* @author       Romano Mauri
* @brief        Funzione per decodificare un buffer ricevuto e memorizzare
*                il dato nelle variabili interne alla classe.
* @date         23.03.2019
* @param[in]    parBuffer = buffer da decodificare.
* @return       TRUE se la decodifica è avvenuta correttamente.
****************************************************************************/

bool MR_Test_Data::Decode( QString parBuffer )
    {
    int i , cnt , posStart , posEnd;
    QString strStart , strEnd , strValue;

    cnt = 0;
    for( i = 0 ; i < 5 ; i++ )
        {
        switch( i )
            {
            case 0 : strStart = TAG_URL_START;       strEnd = TAG_URL_END;       break;
            case 1 : strStart = TAG_TOUT_START;      strEnd = TAG_TOUT_END;      break;
            case 2 : strStart = TAG_VALUE_START;     strEnd = TAG_VALUE_END;     break;
            case 3 : strStart = TAG_TSTAMP_START;    strEnd = TAG_TSTAMP_END;    break;
            case 4 : strStart = TAG_SIMULATOR_START; strEnd = TAG_SIMULATOR_END; break;
            }

        posStart = posEnd = parBuffer.indexOf( strStart );
        if( posStart >= 0 )
            posEnd = parBuffer.indexOf( strEnd , posStart );

        if( posStart >= 0 && posEnd >= 0 )
            {
            posStart += strStart.length();
            strValue = parBuffer.mid( posStart , posEnd - posStart );

            switch( i )
                {
                case 0 : m_UrlAddress = strValue;                                cnt++;  break;
                case 1 : m_msTimeQuery = strValue.toInt();                       cnt++;  break;
                case 2 : m_Value = strValue.toDouble();                          cnt++;  break;
                case 3 : m_TimeStamp = strValue.toLong();                        cnt++;  break;
                case 4 : m_Simulator = ( strValue.toInt() != 0 ) ? true : false; cnt++;  break;
                }
            }
        }
    return(( cnt > 0 ) ? true : false );
    }

/****************************************************************************/
