/****************************************************************************/
/* File        : MR_Test_Engine.cpp                                         */
/* Author      : Romano Mauri                                               */
/* Creation    : 22.03.2019                                                 */
/* Description : Classe di gestione della sincronizzazione dei dati.        */
/****************************************************************************/

#include "MR_Test_Engine.h"
#include "MR_Test_Data.h"

#include <QMessageBox>

/*! *************************************************************************
* @par          MR_Test_Engine
* @author       Romano Mauri
* @brief        Costruttore della classe.
* @date         22.03.2019
****************************************************************************/

MR_Test_Engine::MR_Test_Engine( )
    {
    m_Client = NULL;

    connect( &m_timer , SIGNAL( timeout()) , this , SLOT( TimeOut()));
    m_timer.start( 1000 );
    
    m_HttpServer = new QNetworkAccessManager( this );
    connect( m_HttpServer , SIGNAL( finished( QNetworkReply * )) , this , SLOT( HttpDataReady( QNetworkReply * )));
    //m_Service = NULL;

    m_rnd = new QRandomGenerator( QDateTime::currentMSecsSinceEpoch());
    
    m_CicloThread = true;
    m_Client = new QTcpSocket( this );
    if( m_Client )
        {
        m_Client->connectToHost( "127.0.0.1" , TCP_PORT );
        connect( m_Client , SIGNAL( readyRead()) , this , SLOT( ServerData()));
        }
    }

/*! *************************************************************************
* @par          ~MR_Test_Engine
* @author       Romano Mauri
* @brief        Distruttore della classe.
* @date         22.03.2019
****************************************************************************/

MR_Test_Engine::~MR_Test_Engine( )
    {
    StopEngine();
    if( m_HttpServer )
        {
        delete m_HttpServer;
        m_HttpServer = NULL;
        }
    
    if( m_rnd )
        delete m_rnd;
    }

/*! *************************************************************************
* @par          StopEngine
* @author       Romano Mauri
* @brief        Funzione per forzare l'uscita dal thread.
* @date         22.03.2019
****************************************************************************/

void MR_Test_Engine::StopEngine()
    {
    m_CicloThread = false;
    m_timer.start( 1 );
    }

/*! *************************************************************************
* @par          isRunning
* @author       Romano Mauri
* @brief        Funzione per restituire lo stato di esecuzione del motore.
* @date         22.03.2019
* @return       TRUE se il motore è in esecuzione.
****************************************************************************/

bool MR_Test_Engine::isRunning()
    {
    return( m_CicloThread );
    }

/*! *************************************************************************
* @par          ServerData
* @author       Romano Mauri
* @brief        Funzione richiamata alla ricezione di nuovi dati.
*                Il pacchetto ricevuto contiene l'indicazione dell'URL
*                a cui connettersi e la frequenza di interrogazione.
* @date         23.03.2019
****************************************************************************/

void MR_Test_Engine::ServerData()
    {
    bool ret;
    QByteArray buffer;

    buffer.clear();
    if( m_Client )
        {
        while( m_Client->bytesAvailable() > 0 )
            buffer.append( m_Client->readAll());
        }

    if( buffer.length() > 0 )
        {
        ret = m_Data.Decode( QString::fromLocal8Bit( buffer.data()));
        if( ret )
            m_timer.start( m_Data.GetTimeQuery());
        }
    }

/*! *************************************************************************
* @par          TimeOut
* @author       Romano Mauri
* @brief        Funzione richiamata alla scadenza del timer.
*                Se l'indirizzo è valido si procede ad una nuova interrogazione
*                del servizio.
* @date         23.03.2019
****************************************************************************/

void MR_Test_Engine::TimeOut()
    {
    if( !m_CicloThread )
        {
        m_timer.stop();

        if( m_Client )
            {
            disconnect( this , SLOT( ServerData()));
            m_Client->disconnectFromHost();
            m_Client->close();
            //delete m_Client;
            m_Client = NULL;
            }
        } 
    else if( !m_Data.GetAddress().isEmpty() && m_HttpServer )
        {
        if( m_Data.IsSimulator())
            {
            QDateTime t = QDateTime( QDate( 2000 , 1 , 1 ) , QTime( 0 , 0 ));
            QString jBuffer;
            
            jBuffer.sprintf( "{\"last\": \"%.2f\", \"timestamp\": \"%lld\"}" , 
                             m_rnd->bounded( 50 , 15000 ) / 100.0 , t.secsTo( QDateTime::currentDateTime()));
            JsonDecoder( jBuffer );
            }
        else
            {
            QUrlQuery query;
            query.clear();
            //query.addQueryItem("key", key);
            //query.addQueryItem("lang", lang);
            //query.addQueryItem("text", text);

            QSslConfiguration config( QSslConfiguration::defaultConfiguration());
            config.setProtocol( QSsl::TlsV1_2 );

            QUrl url( m_Data.GetAddress());
            url.setQuery( query );

            QNetworkRequest request;
            request.setSslConfiguration( config );
            request.setUrl( url );
            request.setHeader( /*QNetworkRequest::ContentTypeHeader*/ QNetworkRequest::ServerHeader , "application/json" );

            //m_HttpServer->setStrictTransportSecurityEnabled( true );
            QNetworkReply *ret = m_HttpServer->get( request );
            //ret->ignoreSslErrors();
            }
        }
    }

/*! *************************************************************************
* @par          HttpDataReady
* @author       Romano Mauri
* @brief        Funzione richiamata alla ricezione di nuovi dati.
*                Il pacchetto ricevuto contiene l'indicazione dell'URL
*                a cui connettersi e la frequenza di interrogazione.
* @date         23.03.2019
****************************************************************************/

void MR_Test_Engine::HttpDataReady( QNetworkReply *pResult )
    {
    if( pResult->error() > 0 )
        QMessageBox::information( NULL , "TEST - Error" , pResult->errorString());
    
    if( pResult->error() == QNetworkReply::NoError )
        {
        QString strResult = QString::fromLocal8Bit( pResult->readAll());
        //QMessageBox::information( NULL , "TEST" , strResult );
        JsonDecoder( strResult );
        }
    pResult->deleteLater();
    }

/*! *************************************************************************
* @par          JsonDecoder
* @author       Romano Mauri
* @brief        Funzione per decodificare una stringa contenente dati
*                in formato JSON.
*                Alla fine della decodifica viene inviato il dato ricevuto
*                alla classe di visualizzazione tramite socket.
* @date         23.03.2019
* @param[in]    jBuffer = stringa in formato JSON.
****************************************************************************/

void MR_Test_Engine::JsonDecoder( QString jBuffer )
    {
    QJsonDocument retValue = QJsonDocument::fromJson( jBuffer.toLocal8Bit());

    QJsonObject dataSet = retValue.object();
    QStringList strList = dataSet.keys();
    for( int i = 0 ; i < strList.size() ; i++ )
        {
        QJsonValue value = dataSet.value( strList.at( i ));

        if( strList.at( i ).compare( "last" ) == 0 )
            {
            m_Data.SetValue( value.toString().toDouble());
            }
        else if( strList.at( i ).compare( "timestamp" ) == 0 )
            {
            m_Data.SetTimeStamp( value.toString().toLong());
            }
        }
    QString strValue = m_Data.EncodeValue();
    if( m_Client )
        m_Client->write( strValue.toLocal8Bit());
    }

/****************************************************************************/
